
### Project overview is on the GitHub Wiki tab, our [HOMEPAGE](http://r-datatable.com)


